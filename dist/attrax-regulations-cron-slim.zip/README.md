# attrax-regulations-cron

火鹰合规（Attrax）法规监控数据包 — 精简版，只保留两样东西：

1. **每天更新的网址**：`regulation_sources/official_sources.json` — 25 个官方来源（EU Cellar / eCFR+Federal Register / 加拿大 Justice Laws / GOV.UK / NZ Product Safety），watchdog 每日 03:00（服务器本地时区）轮询的清单。
2. **现在用到的法规文件原文**：`regulation_supplements/{批次}/raw/**` 下 33 个文件（约 51MB），即上述 25 个来源首次采集时落盘的原文（RDF / XHTML / XML / HTML）。`official_sources.json` 里每条 `files[]` 数组就是指向这些文件的相对路径。

目录结构保留批次前缀（`2026-05-25_official_sources` 等），这样 `files[]` 的相对引用不需要改写即可继续解析。

## 来源明细

| 市场 | 来源类型 | 数量 | 说明 |
|------|---------|------|------|
| EU | `eu_celex` | 8 | GPSR、玩具、RoHS、WEEE、RED、EMC、LVD、市场监督 — Cellar 内容协商端点 |
| US | `ecfr_part` | 5 | 16 CFR 1307/1630/1631/1633/1700 |
| CA | `canada_justice_xml` | 6 | 化学品容器、涂层、邻苯二甲酸酯、儿童睡衣、含铅、拉绳窗帘 |
| UK | `gov_html` | 4 | WEEE、包装 EPR、REACH、SVHC |
| NZ | `direct_url` | 2 | 玩具标准、家用婴儿床标准 |

## 被裁掉的内容（相对完整数据包）

- 其余 6 个历史批次中未被 25 个监控来源引用的 ~350MB PDF/XML（已消化进 corpus，watchdog 不再读）
- watchdog 每日输出（`watchdog-{date}/`、`auto-{date}/`、快照缓存 `.cache.db`）— 服务器本地生成，不入库
- `regulations/`（结构化 YAML 法规库）与 `kb/anchors/` — 属于主项目仓库 `attrax`

## 与主项目的关系

轮询与自动摄取逻辑在主仓库 `attrax` 的 `scripts/watchdog/`（orchestrator.py 读 `data/regulation_sources/official_sources.json`）。本仓库只承载数据：URL 清单 + 原文存档。
